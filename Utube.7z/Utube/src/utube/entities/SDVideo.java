package utube.entities;

public class SDVideo extends Video{

}
