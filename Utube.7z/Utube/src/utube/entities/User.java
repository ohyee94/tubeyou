package utube.entities;

import javax.persistence.*;
import java.io.*;
import java.util.*;

@Entity
@Table(name = "user", catalog = "utube")
public class User implements Serializable {
	private Integer userID;
	private String name;
	private String mail;
	private Set<Comment> comments = new HashSet<Comment>();
	private Set<Video> videos = new HashSet<Video>();

	public User() {
		super();
	}

	public User(Integer userID, String name, String mail) {
		super();
		this.userID = userID;
		this.name = name;
		this.mail = mail;
	}

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "user_id", length = 11, nullable = false)
	public Integer getUserID() {
		return userID;
	}

	public void setUserID(Integer userID) {
		this.userID = userID;
	}

	@Column(name = "name", length = 250, nullable = false)
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Column(name = "mail", length = 250, nullable = false)
	public String getMail() {
		return mail;
	}

	public void setMail(String mail) {
		this.mail = mail;
	}

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "user")
	public Set<Comment> getComments() {
		return comments;
	}

	public void setComments(Set<Comment> comments) {
		this.comments = comments;
	}
	
//	@OneToMany(fetch = FetchType.LAZY, mappedBy = "user")
//	public Set<Video> getVideos() {
//		return videos;
//	}
//
//	public void setVideos(Set<Video> videos) {
//		this.videos = videos;
//	}

}
