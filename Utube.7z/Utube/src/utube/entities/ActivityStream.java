package utube.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.*;

import com.mysql.fabric.jdbc.FabricMySQLDataSource;

@Entity
@Table(name = "activitystream", catalog = "utube")
public class ActivityStream implements Serializable {

	private ActivityStreamPK pk;
	private String activityType;
	private Date date;
	
	@EmbeddedId
	public ActivityStreamPK getPk() {
		return pk;
	}

	public void setPk(ActivityStreamPK pk) {
		this.pk = pk;
	}

	@Column(name="activity_type",length=250,nullable=false)
	public String getActivityType() {
		return activityType;
	}

	public void setActivityType(String activityType) {
		this.activityType = activityType;
	}

	@Temporal(TemporalType.DATE)
	@Column(name="date",nullable=false)
	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

}
