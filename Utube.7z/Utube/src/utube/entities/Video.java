package utube.entities;

import java.io.Serializable;
import java.util.*;

import javax.persistence.*;

@Entity
@Table(name = "video", catalog = "utube")
public class Video implements Serializable {
	private Integer videoID;
	private String title;
	private Date date;
	private String video_type;
	private Integer author;
	private Set<Comment> comments = new HashSet<Comment>();
	private User user;

	public Video() {
		super();
	}

	public Video(Integer videoID, String title, Date date, String video_type, Set<Comment> comments) {
		super();
		this.videoID = videoID;
		this.title = title;
		this.date = date;
		this.video_type = video_type;
		this.comments = comments;
	}

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "video_id", length = 11, nullable = false)
	public Integer getVideoID() {
		return videoID;
	}

	public void setVideoID(Integer videoID) {
		this.videoID = videoID;
	}

	@Column(name = "title", length = 250, nullable = false)
	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "date_creation", nullable = false)
	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	@Column(name = "video_type", length = 250, nullable = false)
	public String getVideo_type() {
		return video_type;
	}

	public void setVideo_type(String video_type) {
		this.video_type = video_type;
	}
	
	@Column(name="author_id",length=11, nullable=false)
	public Integer getAuthor() {
		return author;
	}

	public void setAuthor(Integer author) {
		this.author = author;
	}

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "video")
	public Set<Comment> getComments() {
		return comments;
	}

	public void setComments(Set<Comment> comments) {
		this.comments = comments;
	}

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "author_id", nullable = false, insertable = false, updatable = false)
	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

}
