package utube.entities;

public class HDVideo extends Video{

}
