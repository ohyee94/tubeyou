package utube.entities;

import java.io.Serializable;

import javax.persistence.*;

@Embeddable
public class ActivityStreamPK implements Serializable{
	private Integer asID;
	private Integer userID;
	private Integer videoID;

	@Column(name="activity_stream_id",length=11,nullable=false)
	public Integer getAsID() {
		return asID;
	}

	public void setAsID(Integer asID) {
		this.asID = asID;
	}
	@Column(name="user_id",length=11,nullable=false)
	public Integer getUserID() {
		return userID;
	}

	public void setUserID(Integer userID) {
		this.userID = userID;
	}
	@Column(name="video_id",length=11,nullable=false)
	public Integer getVideoID() {
		return videoID;
	}

	public void setVideoID(Integer videoID) {
		this.videoID = videoID;
	}
	
	public int hashCode(){
		int result = 13;
		result = 33 * result + this.getAsID();
		result = 33 * result + this.getUserID();
		result = 33 * result + this.getVideoID();
		return result;
	}
}
