package utube.dao;

import utube.entities.*;
import java.util.*;
import org.hibernate.*;
import org.hibernate.criterion.Restrictions;

public class VideoDAO {

	private SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
	
	@SuppressWarnings("unchecked")
	public List<Video> findAll(){
		try {
			if(!sessionFactory.getCurrentSession().getTransaction().isActive())
				sessionFactory.getCurrentSession().beginTransaction();
			return sessionFactory.getCurrentSession().createCriteria(Video.class).list();
		} catch (Exception e) {
			System.out.println(e.getMessage());
			return null;
		}
	}
	
	@SuppressWarnings("unchecked")
	public Video findVideoID(Integer videoid){
		try {
			if(!sessionFactory.getCurrentSession().getTransaction().isActive())
				sessionFactory.getCurrentSession().beginTransaction();
			return (Video)sessionFactory.getCurrentSession().createCriteria(Video.class).add(Restrictions.eq("videoID",videoid)).uniqueResult();
		} catch (Exception e) {
			System.out.println(e.getMessage());
			return null;
		}
	}
//	@SuppressWarnings("unchecked")
//	public Video findUserID(Integer userid){
//		try {
//			if(!sessionFactory.getCurrentSession().getTransaction().isActive())
//				sessionFactory.getCurrentSession().beginTransaction();
//			return (Video)sessionFactory.getCurrentSession().createCriteria(Video.class).add(Restrictions.eq("author",userid)).uniqueResult();
//		} catch (Exception e) {
//			System.out.println(e.getMessage());
//			return null;
//		}
//	}
	@SuppressWarnings("unchecked")
	public List<Video> findUserID(Integer userid){
		try {
			if(!sessionFactory.getCurrentSession().getTransaction().isActive())
				sessionFactory.getCurrentSession().beginTransaction();
			return sessionFactory.getCurrentSession().createCriteria(Video.class).add(Restrictions.eq("author", userid)).list();
		} catch (Exception e) {
			System.out.println(e.getMessage());
			return null;
		}
	}
	
	@SuppressWarnings("unchecked")
	public List<Video> findUserID_HD(){
		try {
			if(!sessionFactory.getCurrentSession().getTransaction().isActive())
				sessionFactory.getCurrentSession().beginTransaction();
			return sessionFactory.getCurrentSession().createCriteria(Video.class).add(Restrictions.eq("video_type",String.valueOf("HD"))).list();
		} catch (Exception e) {
			System.out.println(e.getMessage());
			return null;
		}
	}
	public static List<String> removeDuplicate(List<String> l6)
	{
	    HashSet h = new HashSet(l6);
	    l6.clear();
	    l6.addAll(h);
	   
	    return l6;
	                   
	}
}
