package Main;

import utube.entities.*;
import utube.dao.*;
import java.util.*;

public class Main {

	public static void main(String[] args) {

		VideoDAO vDAO = new VideoDAO();
		List<Video> list = new ArrayList<Video>(vDAO.findAll());

		System.out.println("We have " + list.size() + " videos in the database");
		//

		//
		// Video v2 = vDAO.find(2);
		// System.out.println(v2.getTitle());
		// System.out.println(v2.getUser().getName());
		// for(Comment c : v2.getComments()){
		// System.out.println(c.getUser().getName());
		// System.out.println(c.getContent());
		// System.out.println(c.getDate());
		// }

		// �Show the titles of all videos in the database.
		System.out.println("The titles of all videos in the database:");
		for (Video v : list) {
			System.out.println(v.getVideoID() + "-" + v.getTitle());
		}

		// � Show the titles of all videos authored by a given user.
		
		List<Video> list2 = new  ArrayList<Video>(vDAO.findUserID(1));
		System.out.println("The title of all videos authored by user: ");
		for(Video v2: list2){
			System.out.println(v2.getVideoID() + " - "+v2.getTitle());
		}
		
		// � Show the titles of all videos authored by user one that user two
		// commented on.
		
		// � Show the titles of all videos that received comments during the
		// last week.
		
		// � Show the title of the video that received the most comments.
		
		// � Show all users that authored HD videos.
		System.out.println("All users have HD videos:");
		List<Video> list6 = new ArrayList<Video>(vDAO.findUserID_HD());
		List<String> l6 = new ArrayList<String>();
		for(Video v6 : list6){
			l6.add(v6.getUser().getName());
		}
		vDAO.removeDuplicate(l6);
		for(String a : l6){
			System.out.println(a);
		}
	}
}
